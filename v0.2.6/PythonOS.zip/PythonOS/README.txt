PythonOS (CLI) is licensed with GNU 3.0 by RGB Fusion Studios

ABOUT:
  PythonOS is a custom Command Line Interface (CLI) written in Python for coders, geeks, and anybody wanting to experiment with Python.

  Our YouTube channel: https://www.youtube.com/@rgbfusionstudios
  GroupMe: https://groupme.com/join_group/107790588/MN4B0UjW

CONTRIBUTORS:
  Main Developer:
    James Farnsworth (The Farlander)

  Support:
    Nick Eborn (Acoustic)
    Harrison Foresman (The Red Cyclone)
    Caden Whitehead (Goofy_dude246)

Thank you for all the support!