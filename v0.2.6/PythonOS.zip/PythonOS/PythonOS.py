import os
import sys
import time
import datetime
import random
import subprocess
import hashlib
import json
import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.backends import default_backend

try:
    import pygame
    pygame_imported = True
except ImportError:
    pygame_imported = False
    print("Warning: Pygame library not found. Audio player and system sounds will not work.")
    print("To install, run: pip install pygame")


VERSION = "v0.2.6"
CONFIG_FILE = "config.txt"
CALENDAR_FILE = "calendar.txt"
USERS_FILE = "users.txt"
PASSWD_FILE = "passwd.txt"
ENCRYPTION_KEY_FILE = "encryption.key"

PREDEFINED_SOUND_NAMES = {
    'power_on': ['power_on', 'startup'],
    'power_off': ['power_off', 'shutdown'],
    'notification': ['notification', 'chime', 'bell'],
    'error': ['error', 'buzz', 'fail']
}
COMMON_SOUND_EXTENSIONS = ('.mp3', '.wav', '.ogg')
SOUND_CATEGORIES = list(PREDEFINED_SOUND_NAMES.keys())

encryption_key = None
settings = {}
user_data = ""
passwd_hash = ""
passwd_salt = ""

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def _generate_key(password):
    password = password.encode()
    salt = os.urandom(16)
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )
    key = base64.urlsafe_b64encode(kdf.derive(password))
    return key, base64.urlsafe_b64encode(salt)

def _get_password_hash(password, salt):
    password = password.encode('utf-8')
    digest = hashes.Hash(hashes.SHA256(), backend=default_backend())
    digest.update(password)
    digest.update(base64.urlsafe_b64decode(salt))
    return base64.urlsafe_b64encode(digest.finalize())

def _read_encrypted_file(filename):
    global encryption_key
    if not os.path.exists(filename):
        return None

    try:
        with open(filename, 'rb') as f:
            encrypted_data = f.read()
        f = Fernet(encryption_key)
        decrypted_data = f.decrypt(encrypted_data)
        return decrypted_data.decode('utf-8')
    except Exception as e:
        print(f"Error decrypting file '{filename}': {e}")
        return None

def _write_encrypted_file(filename, data):
    global encryption_key
    try:
        temp_filename = filename + '.tmp'
        f = Fernet(encryption_key)
        encrypted_data = f.encrypt(data.encode('utf-8'))

        with open(temp_filename, 'wb') as f_temp:
            f_temp.write(encrypted_data)

        os.replace(temp_filename, filename)
    except Exception as e:
        print(f"Error encrypting or writing to file '{filename}': {e}")

def _play_system_sound(sound_type):
    if not pygame_imported:
        return

    sound_path = settings.get(f'current_{sound_type}_sound', 'None')
    if sound_path == 'None':
        return

    try:
        pygame.mixer.init()
        pygame.mixer.music.load(sound_path)
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy():
            pygame.time.Clock().tick(10)
    except pygame.error as e:
        print(f"Error playing sound '{sound_path}': {e}")
    finally:
        if pygame.mixer.get_init():
            pygame.mixer.quit()

def load_settings():
    global settings, user_data, passwd_hash, passwd_salt

    config_data = _read_encrypted_file(CONFIG_FILE)
    if config_data:
        try:
            settings = json.loads(config_data)
        except json.JSONDecodeError:
            print("Error: Could not decode configuration file. Using default settings.")
            settings = {'setup_completed': 'false'}
    else:
        settings = {'setup_completed': 'false'}

    user_data_str = _read_encrypted_file(USERS_FILE)
    if user_data_str:
        user_data = user_data_str.strip()

    passwd_data_str = _read_encrypted_file(PASSWD_FILE)
    if passwd_data_str:
        try:
            passwd_json = json.loads(passwd_data_str)
            passwd_hash = passwd_json.get('hash')
            passwd_salt = passwd_json.get('salt')
        except (json.JSONDecodeError, TypeError):
            print("Error: Could not decode password file. Resetting required.")
            passwd_hash = None
            passwd_salt = None

def save_settings():
    global settings
    _write_encrypted_file(CONFIG_FILE, json.dumps(settings))

def get_thanksgiving_date(year):
    nov_first = datetime.date(year, 11, 1)
    day_of_week = nov_first.weekday()
    days_to_first_thursday = (3 - day_of_week + 7) % 7
    first_thursday = nov_first + datetime.timedelta(days=days_to_first_thursday)
    thanksgiving = first_thursday + datetime.timedelta(weeks=3)
    return thanksgiving

def get_available_predefined_sounds(sound_type):
    available_sounds = []
    current_dir = os.getcwd()
    for base_name_prefix in PREDEFINED_SOUND_NAMES[sound_type]:
        for ext in COMMON_SOUND_EXTENSIONS:
            full_path = os.path.join(current_dir, f"{base_name_prefix}{ext}")
            if os.path.exists(full_path) and os.path.isfile(full_path):
                available_sounds.append(full_path)
                break
    return available_sounds

def setup_PythonOS():
    global encryption_key, user_data, passwd_hash, passwd_salt, settings

    for f in [CONFIG_FILE, USERS_FILE, PASSWD_FILE, ENCRYPTION_KEY_FILE, CALENDAR_FILE]:
        if os.path.exists(f):
            os.remove(f)

    clear_screen()
    print("--- PythonOS First-Time Setup ---")

    while True:
        username = input("Enter a new username: ").strip()
        if username:
            break
        else:
            print("Username cannot be empty. Please try again.")

    while True:
        password = input("Enter a new password for PythonOS: ").strip()
        confirm_password = input("Confirm the new password: ").strip()
        if password and password == confirm_password:
            break
        else:
            print("Passwords do not match or cannot be empty. Please try again.")

    encryption_key, _ = _generate_key(password)
    with open(ENCRYPTION_KEY_FILE, "wb") as f:
        f.write(encryption_key)

    # Generate a new salt for the password hash
    passwd_salt_bytes = os.urandom(16)
    passwd_salt = base64.urlsafe_b64encode(passwd_salt_bytes).decode('utf-8')
    passwd_hash = _get_password_hash(password, passwd_salt).decode('utf-8')

    user_data = username

    _write_encrypted_file(USERS_FILE, user_data)
    passwd_json = json.dumps({'hash': passwd_hash, 'salt': passwd_salt})
    _write_encrypted_file(PASSWD_FILE, passwd_json)

    settings['setup_completed'] = 'true'
    save_settings()

    print("\nSetup complete. Please log in with your new credentials.")

def login():
    global user_data, passwd_hash, passwd_salt

    clear_screen()
    print("--- PythonOS Login ---")

    while True:
        user_input = input("Username: ")
        password_input = input("Password: ")

        input_hash = _get_password_hash(password_input, passwd_salt)

        if user_input == user_data and input_hash.decode('utf-8') == passwd_hash:
            clear_screen()
            _play_system_sound('power_on')
            print("\nLogin successful.")
            break
        else:
            clear_screen()
            print("Incorrect user or password.")
            print("\n--- PythonOS Login ---")


def initialize_calendar_file():
    calendar_data = _read_encrypted_file(CALENDAR_FILE)

    if not calendar_data:
        print(f"'{CALENDAR_FILE}' not found. Creating file with default holidays...")
        current_year = datetime.datetime.now().year
        thanksgiving_date = get_thanksgiving_date(current_year)

        holidays = [
            f"{current_year}-01-01:New Year's Day:yearly",
            f"{current_year}-02-14:Valentine's Day:yearly",
            f"{current_year}-03-17:St. Patrick's Day:yearly",
            f"{current_year}-07-04:Independence Day:yearly",
            f"{current_year}-10-31:Halloween:yearly",
            f"{thanksgiving_date.strftime('%Y-%m-%d')}:Thanksgiving:yearly",
            f"{current_year}-12-24:Christmas Eve:yearly",
            f"{current_year}-12-25:Christmas Day:yearly",
            f"{current_year}-12-31:New Year's Eve:yearly"
        ]

        _write_encrypted_file(CALENDAR_FILE, '\n'.join(holidays) + '\n')
        print(f"'{CALENDAR_FILE}' created successfully.")


def calendar_app():
    print("\n--- Calendar App ---")
    calendar_data_str = _read_encrypted_file(CALENDAR_FILE)
    events = []
    if calendar_data_str:
        for line in calendar_data_str.strip().split('\n'):
            events.append(line)

    while True:
        clear_screen()
        print("\n--- Calendar ---")
        print("1. Add Event")
        print("2. View Events")
        print("3. Back to CLI")

        choice = input("Enter your choice: ").strip()
        if choice == '1':
            add_event(events)
        elif choice == '2':
            view_events(events)
        elif choice == '3':
            _write_encrypted_file(CALENDAR_FILE, '\n'.join(events) + '\n')
            print("Calendar events saved.")
            break
        else:
            print("Invalid choice. Please try again.")
            time.sleep(1)

def add_event(events):
    clear_screen()
    print("\n--- Add Event ---")
    event_name = input("Enter event name: ").strip()
    event_year = input("Enter year (YYYY): ").strip()
    event_month = input("Enter month (MM): ").strip()
    event_day = input("Enter day (DD): ").strip()

    repeat_status = input("Repeat yearly? (yes/no): ").strip().lower()

    if event_name and event_year and event_month and event_day:
        try:
            full_date = datetime.date(int(event_year), int(event_month), int(event_day))
            full_date_str = full_date.strftime('%Y-%m-%d')
            repeat = "yearly" if repeat_status == "yes" else "none"
            events.append(f"{full_date_str}:{event_name}:{repeat}")
            print(f"Event '{event_name}' on {full_date_str} added successfully.")
            _play_system_sound('notification')
        except ValueError:
            print("Invalid date format. Please enter a valid date.")
    else:
        print("All fields must be filled out.")
    input("\nPress Enter to return to calendar menu...")

def view_events(events):
    clear_screen()
    print("\n--- Your Calendar Events ---")
    if not events:
        print("No events to display.")
    else:
        for event_line in sorted(events):
            full_date_str, name, repeat_status = event_line.strip().split(':')
            print(f"{full_date_str}: {name} ({repeat_status})")
    input("\nPress Enter to return to calendar menu...")


def list_audio_files(directory):
    audio_extensions = ('.mp3', '.wav', '.ogg')
    return [f for f in os.listdir(directory) if f.endswith(audio_extensions)]

def play_audio(file_path):
    if not pygame_imported:
        print("Cannot play audio: Pygame not installed.")
        return

    try:
        pygame.mixer.init()
        pygame.mixer.music.load(file_path)
        pygame.mixer.music.set_volume(0.5)
        pygame.mixer.music.play()

        print(f"\nPlaying: {os.path.basename(file_path)}")
        print("Commands: 'pause' | 'resume' | 'stop' | 'volume [0-100]' | 'back'")

        is_paused = False
        while pygame.mixer.music.get_busy() or is_paused:
            command = input("> ").strip().lower()

            if command == "pause":
                if not is_paused:
                    pygame.mixer.music.pause()
                    is_paused = True
                    print("Paused.")
                else:
                    print("Already paused.")
            elif command == "resume":
                if is_paused:
                    pygame.mixer.music.unpause()
                    is_paused = False
                    print("Resumed.")
                else:
                    print("Not currently paused.")
            elif command == "stop" or command == "back":
                pygame.mixer.music.stop()
                print("Stopped.")
                break
            elif command.startswith("volume"):
                try:
                    volume_level = int(command.split()[1]) / 100.0
                    if 0.0 <= volume_level <= 1.0:
                        pygame.mixer.music.set_volume(volume_level)
                        print(f"Volume set to {int(volume_level * 100)}%")
                    else:
                        print("Volume must be between 0 and 100.")
                except (IndexError, ValueError):
                    print("Usage: volume [0-100]")
            else:
                print("Unknown command. Please use 'pause', 'resume', 'stop', 'back', or 'volume [0-100]'.")

    except pygame.error as e:
        print(f"Error playing audio: {e}. Make sure the file exists and is a supported format.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
    finally:
        if pygame.mixer.get_init():
            pygame.mixer.quit()

def audio_player_main():
    directory = os.getcwd()
    audio_files = list_audio_files(directory)

    if not audio_files:
        print("No audio files found in this directory.")
        return

    while True:
        print("\nAvailable audio files:")
        for idx, file in enumerate(audio_files, 1):
            print(f"{idx}. {file}")

        print("0. Back to CLI")

        try:
            choice = input("\nEnter the number of the file to play (or 0 to exit): ").strip()
            if choice == '0':
                print("Exiting audio player.")
                break

            choice_idx = int(choice) - 1
            if 0 <= choice_idx < len(audio_files):
                play_audio(os.path.join(directory, audio_files[choice_idx]))
            else:
                print("Invalid choice. Please enter a valid number from the list or 0 to exit.")
        except ValueError:
            print("Invalid input. Please enter a number.")
        except KeyboardInterrupt:
            print("\nExiting audio player due to user interruption.")
            break

def settings_menu():
    global settings, user_data, passwd_hash, passwd_salt

    while True:
        clear_screen()
        print("\n--- PythonOS Settings ---")
        print("Settings Options:")
        print("1. Customize Sounds")
        print(f"2. Change Username (Current: {user_data})")
        print("3. Change Password")
        print("4. Back to CLI")

        choice = input("Enter your choice: ").strip()

        if choice == '1':
            customize_sounds_menu()
        elif choice == '2':
            clear_screen()
            print("\n--- Change Username ---")
            new_username = input(f"Current Username: {user_data}\nEnter new username: ").strip()
            if new_username:
                confirm = input(f"Are you sure you want to change your username to '{new_username}'? (yes/no): ").lower()
                if confirm == 'yes':
                    user_data = new_username
                    _write_encrypted_file(USERS_FILE, user_data)
                    print("Username changed successfully.")
                else:
                    print("Username change cancelled.")
            else:
                print("Username cannot be empty.")
            input("Press Enter to continue...")
        elif choice == '3':
            clear_screen()
            print("\n--- Change Password ---")
            current_password_input = input("Enter current password to verify: ")

            input_hash = _get_password_hash(current_password_input, passwd_salt)
            if input_hash.decode('utf-8') == passwd_hash:
                new_password = input("Enter new password: ")
                confirm_new_password = input("Confirm new password: ")
                if new_password == confirm_new_password:
                    if new_password:
                        new_salt_bytes = os.urandom(16)
                        passwd_salt = base64.urlsafe_b64encode(new_salt_bytes).decode('utf-8')
                        passwd_hash = _get_password_hash(new_password, passwd_salt).decode('utf-8')
                        passwd_json = json.dumps({'hash': passwd_hash, 'salt': passwd_salt})
                        _write_encrypted_file(PASSWD_FILE, passwd_json)
                        print("Password changed successfully.")
                    else:
                        print("New password cannot be empty.")
                else:
                    print("New passwords do not match.")
            else:
                print("Incorrect current password.")
            input("Press Enter to continue...")
        elif choice == '4':
            clear_screen()
            break
        else:
            print("Invalid choice. Please try again.")
            time.sleep(1)

def customize_sounds_menu():
    global settings
    while True:
        clear_screen()
        print("\n--- Customize System Sounds ---")
        print("Sound Categories:")
        for i, key in enumerate(SOUND_CATEGORIES, 1):
            current_sound_path = settings.get(f'current_{key}_sound', 'None')
            display_name = os.path.basename(current_sound_path) if current_sound_path != 'None' else 'None'
            print(f"{i}. {key.replace('_', ' ').title()} Sounds (Current: {display_name})")

        print(f"{len(SOUND_CATEGORIES)+1}. Back to Settings Menu")

        category_choice = input("Enter a category number to customize: ").strip()

        if category_choice.isdigit() and 1 <= int(category_choice) <= len(SOUND_CATEGORIES):
            selected_category_key = SOUND_CATEGORIES[int(category_choice) - 1]
            clear_screen()
            print(f"\n--- Select {selected_category_key.replace('_', ' ').title()} Sound ---")

            available_files = get_available_predefined_sounds(selected_category_key)
            if not available_files:
                print(f"No predefined sound files found for '{selected_category_key}'.")
                print("Please ensure appropriate files are in the same directory.")
                input("Press Enter to continue...")
                continue

            current_active_sound_path = settings.get(f'current_{selected_category_key}_sound', 'None')
            print(f"Current active sound: {os.path.basename(current_active_sound_path) if current_active_sound_path != 'None' else 'None'}")

            print("\nAvailable Sound Files:")
            sound_display_map = {}
            for idx, file_path in enumerate(available_files, 1):
                display_name = os.path.basename(file_path)
                selected_status = " (Selected)" if file_path == current_active_sound_path else ""
                print(f"{idx}. {display_name}{selected_status}")
                sound_display_map[str(idx)] = file_path

            print("0. Clear active sound (play no sound)")
            print("B. Back to Sound Categories")

            sound_choice = input("Enter the number of the sound to set, 0 to clear, or B to go back: ").strip().upper()

            if sound_choice == '0':
                settings[f'current_{selected_category_key}_sound'] = 'None'
                print(f"Active {selected_category_key.replace('_', ' ')} sound cleared.")
                save_settings()
            elif sound_choice in sound_display_map:
                selected_file_path = sound_display_map[sound_choice]
                settings[f'current_{selected_category_key}_sound'] = selected_file_path
                print(f"Active {selected_category_key.replace('_', ' ')} sound set to '{os.path.basename(selected_file_path)}'.")
                save_settings()
                _play_system_sound(selected_category_key)
            elif sound_choice == 'B':
                continue
            else:
                print("Invalid choice.")

            input("Press Enter to continue...")
        elif category_choice == str(len(SOUND_CATEGORIES) + 1):
            break
        else:
            print("Invalid category choice. Please try again.")

def check_and_notify_today_events():
    calendar_data_str = _read_encrypted_file(CALENDAR_FILE)
    if not calendar_data_str:
        return

    today = datetime.datetime.now().date()
    today_events = []

    for line in calendar_data_str.strip().split('\n'):
        try:
            full_date_str, name, repeat_status = line.strip().split(':')
            if repeat_status == 'yearly':
                try:
                    event_month, event_day = map(int, full_date_str.split('-')[-2:])
                    event_date_this_year = datetime.date(today.year, event_month, event_day)
                    if event_date_this_year == today:
                        today_events.append(name)
                except (ValueError, IndexError):
                    pass
            else:
                try:
                    event_date = datetime.datetime.strptime(full_date_str, '%Y-%m-%d').date()
                    if event_date == today:
                        today_events.append(name)
                except (ValueError, IndexError):
                    pass
        except ValueError:
            continue

    if today_events:
        _play_system_sound('notification')
        print("\n--- Today's Events ---")
        for event_name in today_events:
            print(f"{event_name} Is today!")
        print("----------------------")

        while True:
            print("\n1. Snooze")
            print("2. Dismiss")
            print("3. Party")
            notification_choice = input("Enter your choice: ").strip()

            if notification_choice == '1':
                print("Event snoozed. You'll be reminded next time you log in (if it's still today).")
                break
            elif notification_choice == '2':
                print("Event dismissed for today.")
                break
            elif notification_choice == '3':
                open_party_image()
                party_audio()
                break
            else:
                print("Invalid choice. Please enter 1, 2, or 3.")
        input("\nPress Enter to continue to CLI...")
        clear_screen()

def open_party_image():
    images = ["party_popper.png", "partying_face.png", "confetti_ball.png"]
    selected_image_name = random.choice(images)
    image_path = os.path.join(os.getcwd(), selected_image_name)

    if not os.path.exists(image_path):
        print(f"Error: Image '{selected_image_name}' not found. Please ensure the image files are in the same directory as the script.")
        return

    try:
        if os.name == 'nt':
            os.startfile(image_path)
        elif sys.platform == 'darwin':
            subprocess.run(['open', image_path])
        else:
            subprocess.run(['xdg-open', image_path])
    except Exception as e:
        print(f"An error occurred while trying to open the image: {e}")

def party_audio():
    if not pygame_imported:
        print("Cannot play party audio: Pygame not installed.")
        return

    filename = "party.wav"
    audio_path = os.path.join(os.getcwd(), filename)
    if not os.path.exists(audio_path):
        print(f"Error: Audio file '{filename}' not found. Please ensure the file is in the same directory.")
        return

    try:
        pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
        pygame.mixer.music.load(audio_path)
        print(f"Playing '{filename}'...")
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy():
            pygame.time.Clock().tick(10)
    except pygame.error as e:
        print(f"Error playing audio: {e}")
    finally:
        if pygame.mixer.get_init():
            pygame.mixer.music.stop()
            pygame.mixer.quit()

def reset_PythonOS():
    print("WARNING: This will permanently delete all user data and settings.")
    confirm = input("Are you absolutely sure you want to proceed? Type 'RESET' to confirm: ").strip()
    if confirm == "RESET":
        files_to_delete = [CONFIG_FILE, CALENDAR_FILE, USERS_FILE, PASSWD_FILE, ENCRYPTION_KEY_FILE]
        for f in files_to_delete:
            if os.path.exists(f):
                os.remove(f)
                print(f"Deleted {f}")
        print("PythonOS has been reset. Auto stopping in 3 seconds")
        time.sleep(3)
        sys.exit(0)
    else:
        print("Reset cancelled.")
        time.sleep(1)

def text_editor_app():
    print("\n--- Document Editor ---")
    filename = input("Enter a filename to open or create: ").strip()

    if not filename:
        print("Filename cannot be empty.")
        return

    file_content = ""
    file_path = os.path.join(os.getcwd(), filename)

    if os.path.exists(file_path):
        # Using a special unencrypted read for this app
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                file_content = f.read()
            print(f"Loaded content from '{filename}'.")
            print("---------------------------------------")
            print(file_content)
        except Exception as e:
            print(f"Error reading file '{filename}': {e}")
            return
    else:
        print(f"'{filename}' not found. A new file will be created.")

    print("\nBegin typing. Type 'save' on a new line to save and exit.")
    print("---------------------------------------")

    lines = file_content.split('\n') if file_content else []

    while True:
        line = input()
        if line.lower() == 'save':
            break
        lines.append(line)

    final_content = '\n'.join(lines).strip()

    try:
        # Saving the file without encryption, as it's a simple text editor
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(final_content)
        print(f"File '{filename}' saved successfully.")
    except Exception as e:
        print(f"Error saving file '{filename}': {e}")

    input("\nPress Enter to return to CLI...")


def live_clock_app():
    print("\n--- Live Clock ---")
    print("Press Ctrl+C to stop the clock.")

    try:
        while True:
            clear_screen()
            now = datetime.datetime.now()
            print(f"Current Time: {now.strftime('%H:%M:%S')}")
            print(f"Current Date: {now.strftime('%A, %B %d, %Y')}")
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nClock stopped.")
    finally:
        input("Press Enter to return to CLI...")

def calculator_app():
    print("\n--- Calculator ---")
    print("Enter a mathematical expression (e.g., 5 * (3 + 2) - 10 / 2).")
    print("Type 'exit' to return to CLI.")

    while True:
        expression = input("> ").strip()

        if expression.lower() == 'exit':
            break

        try:
            # Using eval() for flexible expression evaluation
            result = eval(expression)
            print(f"Result: {result}")
        except (SyntaxError, NameError):
            print("Error: Invalid expression. Please check your syntax.")
        except ZeroDivisionError:
            print("Error: Division by zero is not allowed.")
        except Exception as e:
            print(f"An unexpected error occurred: {e}")

    clear_screen()
    CLI()

def CLI():
    print("\nWelcome to PythonOS CLI", VERSION,'!')
    help_text = """
Commands:
help - displays commands
calculator - Launches the calculator app
text - Launches the document editor
time - Launches the live time zone based clock
music - Launches the music/audio player
calendar - Launches the calendar app
aris - Launches my own AI made in Python (Work in progress)
options - Launches the settings menu
reset - Hard resets this PythonOS installation (use at own risk)
exit - Closes the PythonOS CLI"""
    print(help_text)

    while True:
        print('')
        command = input(f"{user_data}@PythonOS_{VERSION} >>> ").strip().lower()

        if command == "help":
            print(help_text)
        elif command == "reset":
            reset_PythonOS()
        elif command == "calculator":
            clear_screen()
            calculator_app()
        elif command == "text":
            clear_screen()
            text_editor_app()
        elif command == "time":
            clear_screen()
            live_clock_app()
        elif command == "music":
            clear_screen()
            audio_player_main()
        elif command == "calendar":
            clear_screen()
            calendar_app()
        elif command == "exit":
            _play_system_sound('power_off')
            time.sleep(0.2)
            break
        elif command == 'options':
            settings_menu()
        elif command == 'aris':
            print("This feature is coming in PythonOS v1.0. Thank you for your patience :)")
        else:
            print("Unknown command. Type 'help' for a list of commands.")


if __name__ == "__main__":

    if not os.path.exists(ENCRYPTION_KEY_FILE):
        setup_PythonOS()

    try:
        with open(ENCRYPTION_KEY_FILE, "rb") as key_file:
            encryption_key = key_file.read()
    except FileNotFoundError:
        print("Error: Encryption key not found. Please run setup again.")
        sys.exit(1)

    load_settings()

    if settings.get('setup_completed') != 'true' or not user_data or not passwd_hash:
        print("System configuration is incomplete or corrupted. Forcing setup.")
        setup_PythonOS()

    login()

    initialize_calendar_file()
    check_and_notify_today_events()

    CLI()

    print("\nShutting down PythonOS. Goodbye!")