# PythonOS v0.2.5
# Copylefted by RGB Fusion Studios with GPL/GNU 3.0

import time
import random
import os
import datetime
import pygame
import subprocess

setup_user = ''
setup_password = ''
version = 'v0.2.5'
CALENDAR_FILE = "calendar.txt"
CONFIG_FILE = "config.txt"

SOUND_CATEGORIES = {
    'save': 'save',
    'notification': 'notification',
    'power_on': 'power_on',
    'power_off': 'shutdown'
}

PREDEFINED_SOUND_NAMES = {
    'save': [f'save_{i}' for i in range(1, 5)],
    'notification': [f'notification_{i}' for i in range(1, 5)],
    'power_on': [f'power_on_{i}' for i in range(1, 5)],
    'power_off': [f'shutdown_{i}' for i in range(1, 5)],
}

COMMON_SOUND_EXTENSIONS = ('.mp3', '.wav', '.ogg')

settings = {}

user_data = ""
passwd_data = ""

def user_add_func(username):
    try:
        with open("users.txt", "w") as user_file:
            user_file.write(username + "\n")
    except IOError as e:
        print(f"Error writing username to file: {e}")

def passwd_add_func(password):
    try:
        with open("passwd.txt", "w") as passwd_file:
            passwd_file.write(password + "\n")
    except IOError as e:
        print(f"Error writing password to file: {e}")

def load_settings():
    global settings
    settings.clear()

    settings['setup_completed'] = 'false'

    for category in SOUND_CATEGORIES:
        for i in range(1, 5):
            settings[f'{category}_{i}'] = 'None'
        settings[f'current_{category}_sound'] = 'None'

    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r') as f:
                for line in f:
                    line = line.strip()
                    if '=' in line:
                        key, value = line.split('=', 1)
                        settings[key] = value
        except Exception as e:
            print(f"Error loading config.txt: {e}. Reinitializing config.")
            save_settings()
    else:
        print(f"{CONFIG_FILE} not found. Initializing with default settings.")
        save_settings()

def save_settings():
    try:
        with open(CONFIG_FILE, 'w') as f:
            for key, value in settings.items():
                f.write(f"{key}={value}\n")
        print("Settings saved successfully to config.txt.")
    except IOError as e:
        print(f"Error saving settings to config.txt: {e}")

def setup_PythonOS():
    global setup_user, setup_password, user_data, passwd_data
    print("Setup required")
    time.sleep(1)
    print("Starting setup...")
    time.sleep(1.5)

    setup_user = input("Please add a user: ")
    user_add_func(setup_user)
    user_data = setup_user

    while True:
        passwd_add = input("Please enter a password: ")
        passwd_confirm = input("Please confirm your password: ")

        if passwd_add != passwd_confirm:
            print("Passwords do not match. Please try again.")
            time.sleep(1)
        else:
            setup_password = passwd_confirm
            passwd_add_func(setup_password)
            passwd_data = setup_password

            settings['setup_completed'] = 'true'
            save_settings()

            print("Setup complete")
            time.sleep(1)

            initialize_calendar_file()

            while True:
                continue_to_login = input("Would you like to proceed to the login screen? [y/n] ").strip().lower()
                if continue_to_login == "y":
                    clear_screen()
                    return
                elif continue_to_login == "n":
                    exit()
                else:
                    print("Invalid input. Please enter 'y' or 'n'.")
    print("Setup complete")

def reset_PythonOS():
    print("\nAttempting to reset PythonOS...")

    current_script_path = os.path.abspath(__file__)
    current_script_name = os.path.basename(current_script_path)

    deleted_count = 0
    skipped_count = 0
    error_count = 0

    files_to_delete = ["users.txt", "passwd.txt", CALENDAR_FILE, CONFIG_FILE]

    for item_name in os.listdir('.'):
        item_path = os.path.join('.', item_name)

        if os.path.isfile(item_path) and item_name != current_script_name and item_name in files_to_delete:
            try:
                os.remove(item_path)
                print(f"Deleted: {item_name}")
                deleted_count += 1
            except OSError as e:
                print(f"Error deleting {item_name}: {e}")
                error_count += 1
        else:
            print(f"Skipped: {item_name} (directory, self, or not a target file)")
            skipped_count += 1

    print(f"\nHard reset completed.")
    print(f"Summary: {deleted_count} files deleted, {skipped_count} items skipped, {error_count} errors.")
    print("Exiting...")
    _play_system_sound('power_off')
    time.sleep(0.2)
    exit()

def help_command():
    clear_screen()
    print("""
Commands:
help - displays commands
rest - Hard resets this PythonOS installation (use at own risk)
calc - Launches the calculator
text - Launches the text editor
time - Launches the live clock
musc - Launches the music player
caln - Launches the calendar
aris - Launches my own AI made in Python (Work in progress)
optn - Launches the settings menu
exit - Closes the PythonOS CLI""")
    CLI()

def get_number_input(prompt):
	while True:
		try:
			value = float(input(prompt))
			return value
		except ValueError:
			print("Invalid input. Please enter a valid number (e.g., 5, 3.14, -2.5)")

def get_operation_choice():
	while True:
		op = input("""
Operations:
  Add is +
  Subtract is -
  Multiply is *
  Divide is /
Operation: """).strip().lower()
		if op in ["+", "-", "*", "/"]:
			return op
		else:
			print("Not a valid operation. Please choose from +, -, *, or /.")

def get_quit_choice():
	while True:
		calc_quit = input("Would you like to quit the calculator? [y/n] ").strip().lower()
		if calc_quit in ["y", "n"]:
			return calc_quit
		else:
			print("Please enter 'y' for yes or 'n' for no.")


def calc():
    print("Welcome to the PythonOS Calculator!")
    while True:
        x = get_number_input("First number: ")
        y = get_number_input("Second number: ")
        op = get_operation_choice()
        if op == "+":
            print(f"Result: {x} + {y} = {x + y}")
        elif op == "-":
            print(f"Result: {x} - {y} = {x - y}")
        elif op == "*":
            print(f"Result: {x} * {y} = {x * y}")
        elif op == "/":
            if y == 0:
                print("Error: Cannot divide by zero.")
            else:
                print(f"Result: {x} / {y} = {x / y}")
        calc_quit = get_quit_choice()
        if calc_quit == "y":
            clear_screen()
            help_command()
            break
        elif calc_quit == 'n':
            clear_screen()

def _get_multiline_input(prompt_message):
    print(prompt_message)
    print("Enter 'DONE' on a new line to finish input.")
    lines = []
    while True:
        line = input()
        if line.strip().upper() == 'DONE':
            break
        lines.append(line)
    return "\n".join(lines)

def _get_filename_input(action):
    allowed_extensions = ('.txt', '.py', '.md', '.json', '.csv', '.xml', '.html', '.css', '.js', '.log')
    while True:
        filename = input(f"Enter the filename for {action} (e.g., my_document.txt): ").strip()
        if not filename:
            print("Filename cannot be empty. Please try again.")
        elif filename.endswith(allowed_extensions):
            return filename
        else:
            print(f"Unsupported file type. Please use one of the following extensions: {', '.join(allowed_extensions)}")


def text_editor():
    clear_screen()
    print("Welcome to the PythonOS Text Editor!")

    protected_files = ["config.txt", "users.txt", "passwd.txt", "PythonOS.py", CALENDAR_FILE]

    while True:
        print("""
--- Menu ---""")
        print("C - Create New File")
        print("V - Open and View File")
        print("E - Edit File (Append/Overwrite)")
        print("D - Delete File")
        print("F - Find and Replace Text")
        print("L - Show All Files in Current Directory")
        print("Q - Exit Editor")

        choice = input("Enter your command (C/V/E/D/F/L/Q): ").strip().upper()

        if choice == 'C':
            filename = _get_filename_input("creating")
            if filename in protected_files:
                print(f"Access Denied: '{filename}' is a protected system file.")
                continue
            try:
                if os.path.exists(filename):
                    confirm = input(f"Warning: File '{filename}' already exists. Overwrite? (yes/no): ").lower()
                    if confirm != 'yes':
                        print("File creation cancelled.")
                        continue

                content = _get_multiline_input("Enter content for the new file:")
                with open(filename, 'w') as f:
                    f.write(content)
                print(f"File '{filename}' created and saved successfully.")
                _play_system_sound('save')
            except IOError as e:
                print(f"Error creating file '{filename}': {e}")
            except Exception as e:
                print(f"An unexpected error occurred: {e}")

        elif choice == 'V':
            filename = _get_filename_input("viewing")
            if filename in protected_files:
                print(f"Access Denied: '{filename}' is a protected system file.")
                continue
            try:
                with open(filename, 'r') as f:
                    content = f.read()
                    print(f"\n--- Content of '{filename}' ---")
                    print(content)
                    print(f"--- End of '{filename}' ---")
            except FileNotFoundError:
                print(f"Error: File '{filename}' not found. Please ensure the name is correct and the file exists.")
            except IOError as e:
                print(f"Error reading file '{filename}': {e}")
            except Exception as e:
                print(f"An unexpected error occurred: {e}")

        elif choice == 'E':
            filename = _get_filename_input("editing")
            if filename in protected_files:
                print(f"Access Denied: '{filename}' is a protected system file.")
                continue
            if not os.path.exists(filename):
                print(f"Error: File '{filename}' not found. Please ensure the name is correct and the file exists.")
                continue

            try:
                with open(filename, 'r') as f:
                    current_content = f.read()
                    print(f"\n--- Current Content of '{filename}' ---")
                    print(current_content)
                    print(f"--- End of Current Content ---")

                print("\nEdit Options:")
                print("A. Append to file")
                print("O. Overwrite file")
                edit_option = input("Choose an option (A/O): ").lower().strip()

                if edit_option == 'a':
                    new_content = _get_multiline_input("Enter content to append:")
                    with open(filename, 'a') as f:
                        f.write("\n" + new_content if current_content else new_content)
                    print(f"Content appended to '{filename}' successfully.")
                    _play_system_sound('save')
                elif edit_option == 'o':
                    confirm = input(f"Warning: This will REPLACE all content in '{filename}'. Continue? (yes/no): ").lower()
                    if confirm != 'yes':
                        print("Overwrite cancelled.")
                        continue
                    new_content = _get_multiline_input("Enter new content to overwrite the file:")
                    with open(filename, 'w') as f:
                        f.write(new_content)
                    print(f"File '{filename}' overwritten successfully.")
                    _play_system_sound('save')
                else:
                    print("Invalid edit option. No changes made.")

            except IOError as e:
                print(f"Error editing file '{filename}': {e}")
            except Exception as e:
                print(f"An unexpected error occurred: {e}")

        elif choice == 'D':
            filename = _get_filename_input("deleting")
            if filename in protected_files:
                print(f"Access Denied: '{filename}' is a protected system file.")
                continue
            try:
                if os.path.exists(filename):
                    confirm = input(f"Are you sure you want to delete '{filename}'? This cannot be undone. (yes/no): ").lower()
                    if confirm == 'yes':
                        os.remove(filename)
                        print(f"File '{filename}' deleted successfully.")
                    else:
                        print("File deletion cancelled.")
                else:
                    print(f"Error: File '{filename}' not found.")
            except OSError as e:
                print(f"Error deleting file '{filename}': {e}")
            except Exception as e:
                print(f"An unexpected error occurred: {e}")

        elif choice == 'F':
            filename = _get_filename_input("finding and replacing in")
            if filename in protected_files:
                print(f"Access Denied: '{filename}' is a protected system file.")
                continue
            if not os.path.exists(filename):
                print(f"Error: File '{filename}' not found. Cannot perform find/replace.")
                continue

            try:
                with open(filename, 'r') as f:
                    content = f.read()

                search_text = input("Enter the text to find: ")
                replace_text = input("Enter the text to replace it with: ")

                if not search_text:
                    print("Text to find cannot be empty. No replacement performed.")
                    continue

                if search_text not in content:
                    print(f"'{search_text}' not found in '{filename}'. No changes made.")
                    continue

                new_content = content.replace(search_text, replace_text)

                confirm = input(f"Found '{search_text}'. Replace all occurrences with '{replace_text}' in '{filename}'? (yes/no): ").lower()
                if confirm == 'yes':
                    with open(filename, 'w') as f:
                        f.write(new_content)
                    print(f"All occurrences of '{search_text}' replaced with '{replace_text}' in '{filename}'.")
                    _play_system_sound('save')
                else:
                    print("Find and replace cancelled. No changes made.")

            except FileNotFoundError:
                print(f"Error: File '{filename}' not found. Cannot perform find/replace.")
            except IOError as e:
                print(f"Error accessing file '{filename}': {e}")
            except Exception as e:
                print(f"An unexpected error occurred: {e}")


        elif choice == 'L':
            print("\n--- Files in Current Directory ---")
            files = [f for f in os.listdir('.') if os.path.isfile(f) and f not in protected_files]
            if files:
                for f in files:
                    print(f)
            else:
                print("No user files found in the current directory.")
            print("--- End of File List ---")

        elif choice == 'Q':
            clear_screen()
            help_command()
            break
        else:
            print("Invalid command. Please enter one of C, V, E, D, F, L, or Q.")

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def clock():
    clear_screen()
    print("Live Clock is running. Press Ctrl+C to stop.")
    _play_system_sound('notification')

    try:
        while True:
            current_time = datetime.datetime.now().strftime("%H:%M:%S")

            print(f"\rCurrent Time: {current_time}", end="", flush=True)

            time.sleep(1)

    except KeyboardInterrupt:
        help_command()
    except Exception as e:
        print(f"\nAn unexpected error occurred: {e}")

def list_audio_files(directory):
    audio_extensions = ('.mp3', '.wav', '.ogg')
    return [f for f in os.listdir(directory) if f.endswith(audio_extensions)]

def play_audio(file_path):
    try:
        pygame.mixer.init()
        pygame.mixer.music.load(file_path)
        pygame.mixer.music.set_volume(0.5)
        pygame.mixer.music.play()

        print(f"\nPlaying: {file_path}")
        print("Commands: 'pause' | 'resume' | 'stop' | 'exit' | 'volume [0-100]'")

        is_paused = False

        while pygame.mixer.music.get_busy() or is_paused:
            command = input("> ").strip().lower()

            if command == "pause":
                if not is_paused:
                    pygame.mixer.music.pause()
                    is_paused = True
                    print("Paused.")
                else:
                    print("Already paused.")
            elif command == "resume":
                if is_paused:
                    pygame.mixer.music.unpause()
                    is_paused = False
                    print("Resumed.")
                else:
                    print("Not currently paused.")
            elif command == "stop":
                pygame.mixer.music.stop()
                print("Stopped.")
                break
            elif command == "exit":
                pygame.mixer.music.stop()
                print("Exiting player.")
                break
            elif command.startswith("volume"):
                try:
                    volume_level = int(command.split()[1]) / 100.0
                    if 0.0 <= volume_level <= 1.0:
                        pygame.mixer.music.set_volume(volume_level)
                        print(f"Volume set to {int(volume_level * 100)}%")
                    else:
                        print("Volume must be between 0 and 100.")
                except (IndexError, ValueError):
                    print("Usage: volume [0-100]")
            else:
                print("Unknown command. Please use 'pause', 'resume', 'stop', 'exit', or 'volume [0-100]'.")

    except pygame.error as e:
        print(f"Error playing audio: {e}. Make sure the file exists and is a supported format.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
    finally:
        if pygame.mixer.get_init():
            pygame.mixer.quit()


def audio_player_main():
    directory = os.getcwd()
    audio_files = list_audio_files(directory)

    if not audio_files:
        print("No audio files found in this directory.")
        return

    print("\nAvailable audio files:")
    for idx, file in enumerate(audio_files, 1):
        print(f"{idx}. {file}")

    while True:
        try:
            choice = int(input("\nEnter the number of the file to play (or 0 to exit): "))

            if choice == 0:
                print("Exiting audio player.")
                break
            elif 1 <= choice <= len(audio_files):
                play_audio(os.path.join(directory, audio_files[choice - 1]))
                another_round = input("\nPlay another file? [y/n]: ").strip().lower()
                while True:
                    if another_round != 'y':
                        print("Exiting audio player.")
                        clear_screen()
                        break
                    else:
                        print("\nAvailable audio files:")
                        for idx, file in enumerate(audio_files, 1):
                            print(f"{idx}. {file}")
            else:
                print("Invalid choice. Please enter a valid number from the list or 0 to exit.")
        except ValueError:
            print("Invalid input. Please enter a number.")
        except KeyboardInterrupt:
            print("\nExiting audio player due to user interruption.")
            break

def initialize_calendar_file():
    holidays = [
        "01-01:New Year's Day:yearly",
        "02-14:Valentine's Day:yearly",
        "03-17:St. Patrick's Day:yearly",
        "07-04:Independence Day (4th of July):yearly",
        "10-31:Halloween:yearly",
        "11-28:Thanksgiving:yearly",
        "12-24:Christmas Eve:yearly",
        "12-25:Christmas Day:yearly",
        "12-31:New Year's Eve:yearly"
    ]

    current_year = datetime.datetime.now().year
    thanksgiving_date = get_thanksgiving_date(current_year)
    holidays[5] = f"{thanksgiving_date.strftime('%m-%d')}:Thanksgiving:yearly"


    if not os.path.exists(CALENDAR_FILE):
        print(f"'{CALENDAR_FILE}' not found. Creating file...")
        try:
            with open(CALENDAR_FILE, 'w') as f:
                for holiday in holidays:
                    f.write(holiday + '\n')
            print(f"'{CALENDAR_FILE}' created successfully")
        except IOError as e:
            print(f"Error creating '{CALENDAR_FILE}': {e}")
    else:
        try:
            with open(CALENDAR_FILE, 'r') as f:
                f.readlines()
        except Exception as e:
            print(f"'{CALENDAR_FILE}' appears corrupted ({e}). Constructing file...")
            try:
                with open(CALENDAR_FILE, 'w') as f:
                    for holiday in holidays:
                        f.write(holiday + '\n')
                print(f"'{CALENDAR_FILE}' recreated successfully")
            except IOError as e:
                print(f"Error recreating '{CALENDAR_FILE}': {e}")

def get_thanksgiving_date(year):
    nov_first = datetime.date(year, 11, 1)
    day_of_week = nov_first.weekday()

    days_to_first_thursday = (3 - day_of_week + 7) % 7
    first_thursday = nov_first + datetime.timedelta(days=days_to_first_thursday)

    thanksgiving = first_thursday + datetime.timedelta(weeks=3)
    return thanksgiving

def add_event():
    event_name = input("Enter event name: ").strip()
    if not event_name:
        print("Event name cannot be empty.")
        return

    while True:
        event_date_str = input("Enter event date (MM-DD, e.g., 01-15 for January 15th): ").strip()
        try:
            datetime.datetime.strptime(event_date_str, '%m-%d')
            break
        except ValueError:
            print("Invalid date format. Please use MM-DD.")

    while True:
        try:
            event_year_str = input("Enter event year (YYYY, leave empty for current year): ").strip()
            current_date = datetime.datetime.now().date()

            if not event_year_str:
                event_year = current_date.year
            else:
                event_year = int(event_year_str)

            if event_year > 2500:
                print("Year cannot exceed 2500.")
                continue

            try:
                full_event_date = datetime.date(event_year, int(event_date_str.split('-')[0]), int(event_date_str.split('-')[1]))
                if full_event_date <= current_date:
                    print("Event date cannot be in the past or today. Please enter a future date.")
                    continue
            except ValueError:
                print("Invalid month/day combination for the specified year. Please re-enter date and year.")
                continue

            break
        except ValueError:
            print("Invalid year format. Please enter a 4-digit number or leave empty.")

    while True:
        repeat_yearly = input("Does this event repeat yearly? [y/n]: ").strip().lower()
        if repeat_yearly in ['y', 'n']:
            repeat_status = 'yearly' if repeat_yearly == 'y' else 'once'
            break
        else:
            print("Invalid input. Please enter 'y' or 'n'.")

    try:
        full_date_str = f"{event_year}-{event_date_str}"
        with open(CALENDAR_FILE, 'a') as f:
            f.write(f"{full_date_str}:{event_name}:{repeat_status}\n")
        print(f"Event '{event_name}' on {full_date_str} added successfully.")
        _play_system_sound('notification')
    except IOError as e:
        print(f"Error adding event: {e}")

def view_events():
    clear_screen()
    print("\n--- Your Calendar Events ---")
    try:
        with open(CALENDAR_FILE, 'r') as f:
            events = f.readlines()
            if not events:
                print("No events found in your calendar.")
                return

            today = datetime.datetime.now().date()

            upcoming_events = []
            today_events = []
            past_events = []

            for line in events:
                try:
                    full_date_str, name, repeat_status = line.strip().split(':')

                    if repeat_status == 'yearly':
                        try:
                            event_month, event_day = map(int, full_date_str.split('-')[-2:])
                            event_date_current_year = datetime.date(today.year, event_month, event_day)
                        except ValueError:
                            event_month, event_day = map(int, full_date_str.split('-'))
                            event_date_current_year = datetime.date(today.year, event_month, event_day)

                        if event_date_current_year == today:
                            today_events.append(f"  {event_date_current_year.strftime('%Y-%m-%d')} - {name} (Yearly - Today!)")
                        elif event_date_current_year > today:
                            upcoming_events.append(f"  {event_date_current_year.strftime('%Y-%m-%d')} - {name} (Yearly)")
                        else:
                            next_year_date = datetime.date(today.year + 1, event_month, event_day)
                            upcoming_events.append(f"  {next_year_date.strftime('%Y-%m-%d')} - {name} (Yearly, Next occurrence)")
                    else:
                        event_date = datetime.datetime.strptime(full_date_str, '%Y-%m-%d').date()

                        if event_date == today:
                            today_events.append(f"  {event_date.strftime('%Y-%m-%d')} - {name} (Today!)")
                        elif event_date > today:
                            upcoming_events.append(f"  {event_date.strftime('%Y-%m-%d')} - {name}")
                        else:
                            past_events.append(f"  {event_date.strftime('%Y-%m-%d')} - {name} (Past event)")
                except ValueError:
                    print(f"  Skipping malformed event entry: {line.strip()}")

            upcoming_events.sort()

            if today_events:
                print("\n--- Events Today ---")
                for event in today_events:
                    print(event)

            if upcoming_events:
                print("\n--- Upcoming Events ---")
                for event in upcoming_events:
                    print(event)

            if past_events:
                past_events.sort()
                print("\n--- Past Events ---")
                for event in past_events:
                    print(event)

    except FileNotFoundError:
        print(f"Calendar file '{CALENDAR_FILE}' not found. No events to display.")
    except IOError as e:
        print(f"Error reading calendar file: {e}")
    except Exception as e:
        print(f"An unexpected error occurred while viewing events: {e}")

    input("\nPress Enter to return to calendar menu...")

def calendar_app():
    while True:
        clear_screen()
        print("\n--- Calendar ---")
        print("1. Add Event")
        print("2. View Events")
        print("3. Back to CLI")

        choice = input("Enter your choice: ").strip()

        if choice == '1':
            add_event()
        elif choice == '2':
            view_events()
        elif choice == '3':
            clear_screen()
            break
        else:
            print("Invalid choice. Please try again.")
        time.sleep(1)

def _play_system_sound(sound_category_key):
    global settings

    sound_file_path = settings.get(f'current_{sound_category_key}_sound')

    if sound_file_path and sound_file_path != 'None' and os.path.exists(sound_file_path) and os.path.isfile(sound_file_path):
        try:
            pygame.mixer.init()
            pygame.mixer.music.load(sound_file_path)
            pygame.mixer.music.set_volume(0.5)
            pygame.mixer.music.play()
            while pygame.mixer.music.get_busy():
                pygame.time.Clock().tick(10)
        except pygame.error as e:
            print(f"Error playing sound '{sound_file_path}': {e}. Check file format or Pygame installation.")
        except Exception as e:
            print(f"An unexpected error occurred during sound playback: {e}")
        finally:
            if pygame.mixer.get_init():
                pygame.mixer.quit()
    elif sound_file_path and sound_file_path != 'None':
        print(f"Warning: Configured sound file '{sound_file_path}' not found for '{sound_category_key}'.")

def get_available_predefined_sounds(sound_type):
    available_sounds = []
    current_dir = os.getcwd()
    for base_name_prefix in PREDEFINED_SOUND_NAMES[sound_type]:
        for ext in COMMON_SOUND_EXTENSIONS:
            full_path = os.path.join(current_dir, f"{base_name_prefix}{ext}")
            if os.path.exists(full_path) and os.path.isfile(full_path):
                available_sounds.append(full_path)
                break
    return available_sounds

def settings_menu():
    global settings

    current_user_display = ""
    current_passwd_display = ""
    try:
        with open("users.txt", "r") as f:
            current_user_display = f.read().strip()
        with open("passwd.txt", "r") as f:
            current_passwd_display = f.read().strip()
    except FileNotFoundError:
        current_user_display = "N/A"
        current_passwd_display = "N/A"
    except IOError as e:
        print(f"Error reading user/password files for display: {e}")
        current_user_display = "Error"
        current_passwd_display = "Error"

    clear_screen()
    print("\n--- PythonOS Settings ---")

    while True:
        print("\nSettings Options:")
        print("1. Customize Sounds")
        print(f"2. Change Username (Current: {current_user_display})")
        print("3. Change Password")
        print("4. Back to CLI")

        choice = input("Enter your choice: ").strip()

        if choice == '1':
            customize_sounds_menu()
        elif choice == '2':
            clear_screen()
            print("\n--- Change Username ---")
            new_username = input(f"Current Username: {current_user_display}\nEnter new username: ").strip()
            if new_username:
                confirm = input(f"Are you sure you want to change your username to '{new_username}'? (yes/no): ").lower()
                if confirm == 'yes':
                    user_add_func(new_username)
                    print("Username change applied. Will reflect on next CLI prompt.")
                    current_user_display = new_username
                else:
                    print("Username change cancelled.")
            else:
                print("Username cannot be empty.")
            input("Press Enter to continue...")
            clear_screen()
        elif choice == '3':
            clear_screen()
            print("\n--- Change Password ---")
            current_password_input = input("Enter current password to verify: ")
            if current_password_input == current_passwd_display:
                new_password = input("Enter new password: ")
                confirm_new_password = input("Confirm new password: ")
                if new_password == confirm_new_password:
                    if new_password:
                        passwd_add_func(new_password)
                        print("Password change applied. Will reflect on next CLI prompt.")
                        current_passwd_display = new_password
                    else:
                        print("New password cannot be empty.")
                else:
                    print("New passwords do not match.")
            else:
                print("Incorrect current password.")
            input("Press Enter to continue...")
            clear_screen()
        elif choice == '4':
            clear_screen()
            break
        else:
            print("Invalid choice. Please try again.")

def customize_sounds_menu():
    global settings
    clear_screen()
    print("\n--- Customize System Sounds ---")

    while True:
        print("\nSound Categories:")

        display_options = []
        for i, (key, val) in enumerate(SOUND_CATEGORIES.items(), 1):
            current_sound_path = settings.get(f'current_{key}_sound', 'None')
            display_name = os.path.basename(current_sound_path) if current_sound_path != 'None' else 'None'
            display_options.append(f"{i}. {key.replace('_', ' ').title()} Sounds (Current: {display_name})")

        for opt in display_options:
            print(opt)

        print(f"{len(SOUND_CATEGORIES)+1}. Back to Settings Menu")

        category_choice = input("Enter a category number to customize: ").strip()

        selected_category_key = None
        for i, (key, val) in enumerate(SOUND_CATEGORIES.items(), 1):
            if category_choice == str(i):
                selected_category_key = key
                break

        if selected_category_key:
            clear_screen()
            print(f"\n--- Select {selected_category_key.replace('_', ' ').title()} Sound ---")

            available_files = get_available_predefined_sounds(selected_category_key)

            if not available_files:
                print(f"No predefined sound files found for '{selected_category_key}'.")
                print(f"Please ensure files like '{PREDEFINED_SOUND_NAMES[selected_category_key][0]}{COMMON_SOUND_EXTENSIONS[0]}' (or similar extensions) are in the same directory as the script.")
                input("Press Enter to continue...")
                clear_screen()
                continue

            current_active_sound_path = settings.get(f'current_{selected_category_key}_sound', 'None')
            print(f"Current active sound: {os.path.basename(current_active_sound_path) if current_active_sound_path != 'None' else 'None'}")

            print("\nAvailable Sound Files:")
            sound_display_map = {}
            for idx, file_path in enumerate(available_files, 1):
                display_name = os.path.basename(file_path)
                selected_status = " (Selected)" if file_path == current_active_sound_path else ""
                print(f"{idx}. {display_name}{selected_status}")
                sound_display_map[str(idx)] = file_path

            print("0. Clear active sound (play no sound)")
            print("B. Back to Sound Categories")

            sound_choice = input("Enter the number of the sound to set, 0 to clear, or B to go back: ").strip().upper()

            if sound_choice == '0':
                settings[f'current_{selected_category_key}_sound'] = 'None'
                print(f"Active {selected_category_key.replace('_', ' ')} sound cleared.")
                save_settings()
            elif sound_choice in sound_display_map:
                selected_file_path = sound_display_map[sound_choice]
                settings[f'current_{selected_category_key}_sound'] = selected_file_path
                print(f"Active {selected_category_key.replace('_', ' ')} sound set to '{os.path.basename(selected_file_path)}'.")
                save_settings()
                _play_system_sound(selected_category_key)
            elif sound_choice == 'B':
                clear_screen()
                continue
            else:
                print("Invalid choice.")

            input("Press Enter to continue...")
            clear_screen()

        elif category_choice == str(len(SOUND_CATEGORIES) + 1):
            clear_screen()
            break
        else:
            print("Invalid category choice. Please try again.")

def check_and_notify_today_events():
    today = datetime.datetime.now().date()
    today_events = []

    try:
        with open(CALENDAR_FILE, 'r') as f:
            for line in f:
                try:
                    full_date_str, name, repeat_status = line.strip().split(':')

                    if repeat_status == 'yearly':
                        event_month, event_day = map(int, full_date_str.split('-')[-2:])
                        event_date_this_year = datetime.date(today.year, event_month, event_day)
                        if event_date_this_year == today:
                            today_events.append(name)
                    else:
                        event_date = datetime.datetime.strptime(full_date_str, '%Y-%m-%d').date()
                        if event_date == today:
                            today_events.append(name)
                except ValueError:
                    continue
    except FileNotFoundError:
        return
    except IOError as e:
        print(f"Error reading calendar file for event check: {e}")
        return

    if today_events:
        _play_system_sound('notification')
        print("\n--- Today's Events ---")
        for event_name in today_events:
            print(f"{event_name} Is today!")
        print("----------------------")

        while True:
            print("\n1. Snooze")
            print("2. Dismiss")
            print("3. Party")
            notification_choice = input("Enter your choice: ").strip()

            if notification_choice == '1':
                print("Event snoozed. You'll be reminded next time you log in (if it's still today).")
                break
            elif notification_choice == '2':
                print("Event dismissed for today.")
                break
            elif notification_choice == '3':
                open_party_image()
                party_audio()
                break
            else:
                print("Invalid choice. Please enter 1, 2, or 3.")
        input("\nPress Enter to continue to CLI...")
        clear_screen()

def open_party_image():
    images = ["party_popper.png", "partying_face.png", "confetti_ball.png"]

    selected_image_name = random.choice(images)

    script_dir = os.path.dirname(os.path.abspath(__file__))
    image_path = os.path.join(script_dir, selected_image_name)

    if not os.path.exists(image_path):
        print(f"Error: Image '{selected_image_name}' not found at '{image_path}'")
        print("Please ensure the image files are in the same directory as the script.")
        return

    try:
        if os.name == 'nt':
            os.startfile(image_path)
        elif os.uname().sysname == 'Darwin':
            subprocess.run(['open', image_path])
        else:
            subprocess.run(['xdg-open', image_path])

    except Exception as e:
        print(f"An error occurred while trying to open the image: {e}")
        print("Ensure your system has a default application associated with .png files.")


def party_audio(filename="party.wav"):
    try:
        pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
    except pygame.error as e:
        print(f"Error initializing mixer: {e}")
        print("Please ensure your audio drivers are correctly installed and configured.")
        return

    script_dir = os.path.dirname(os.path.abspath(__file__))
    audio_path = os.path.join(script_dir, filename)

    if not os.path.exists(audio_path):
        print(f"Error: Audio file '{filename}' not found at '{audio_path}'")
        print("Please ensure the audio file is in the same directory as the script.")
        return

    try:
        pygame.mixer.music.load(audio_path)
        print(f"Loading '{filename}'...")

        pygame.mixer.music.play(0)
        print(f"Playing '{filename}'... (will stop after one playback)")

        while pygame.mixer.music.get_busy():
            pygame.time.Clock().tick(10)

    except pygame.error as e:
        print(f"Error playing audio: {e}")
    finally:
        if pygame.mixer.get_init():
            pygame.mixer.music.stop()
            pygame.mixer.quit()
            CLI()


def CLI():
    global user_data, passwd_data
    while True:
        try:
            with open("users.txt", "r") as user_file:
                user_data = user_file.read().strip()
            with open("passwd.txt", "r") as passwd_file:
                passwd_data = passwd_file.read().strip()
        except FileNotFoundError:
            print("Error: User or password files not found. Please restart PythonOS.")
            exit()
        except IOError as e:
            print(f"Error reading user/password files: {e}. Please restart PythonOS.")
            exit()

        print('')
        command = input(user_data + "@PythonOS_" + version + ">>> ")
        if command == "help":
            help_command()
        elif command == "rest":
            reset_PythonOS()
            break
        elif command == "calc":
            clear_screen()
            calc()
        elif command == "text":
            clear_screen()
            text_editor()
        elif command == "time":
            clear_screen()
            clock()
        elif command == "musc":
            clear_screen()
            audio_player_main()
        elif command == "caln":
            clear_screen()
            calendar_app()
        elif command == "exit":
            _play_system_sound('power_off')
            time.sleep(0.2)
            exit()
        elif command == 'optn':
            settings_menu()
        elif command == 'aris':
            print("This feature is coming in PythonOS v1.0. Thank you for your patience :)")
        else:
            print("Unknown command. Try help for a list of currently available commands.")


clear_screen()

load_settings()

setup_completed = settings.get('setup_completed') == 'true'

if not setup_completed:
    print("Configuration file not found or setup not completed. Initializing setup.")
    if os.path.exists("users.txt"):
        os.remove("users.txt")
    if os.path.exists("passwd.txt"):
        os.remove("passwd.txt")
    setup_PythonOS()
else:
    initialize_calendar_file()

try:
    with open("users.txt", "r") as user_file:
        user_data = user_file.read().strip()
    with open("passwd.txt", "r") as passwd_file:
        passwd_data = passwd_file.read().strip()
except FileNotFoundError:
    print("User or password files not found after initial checks. Forcing setup.")
    settings['setup_completed'] = 'false'
    save_settings()
    setup_PythonOS()
except IOError as e:
    print(f"Error reading user/password files during initial load: {e}. Forcing setup.")
    settings['setup_completed'] = 'false'
    save_settings()
    setup_PythonOS()


while True:
    user_input = input("Username: ")
    password_input = input("Password: ")

    if user_input == user_data and password_input == passwd_data:
        clear_screen()
        _play_system_sound('power_on')
        break
    else:
        clear_screen()
        print("Incorrect user or password")

check_and_notify_today_events()

print("\nWelcome to PythonOS CLI", version,'!')
print("""
Commands:
help - displays commands
rest - Hard resets this PythonOS installation (all data)
calc - Launches the calculator
text - Launches the text editor
time - Launches the live clock
musc - Launches the music player
caln - Launches the calendar
aris - Launches my own AI made in Python (Work in progress)
optn - Launches the settings menu
exit - Closes the PythonOS CLI""")
CLI()